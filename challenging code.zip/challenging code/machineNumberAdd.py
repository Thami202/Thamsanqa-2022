def add_digit(text):
    l = []

    for num in text:
        if num.isdigit(): 
            num = int(num) + 1
            if num > 9:
                num = 0
            num = str(num) 
        l.append(num)
    return ''.join(l)

print (add_digit('56789'))